import React, { useState, useEffect, useRef } from 'react';
import { Search, Moon, Sun, X } from 'lucide-react';
import { useNews } from '../context/NewsContext';

const Header: React.FC = () => {
  const { state, dispatch, fetchNewsData } = useNews();
  const [searchValue, setSearchValue] = useState('');
  const [isSearchVisible, setIsSearchVisible] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);
  
  // Handle search input changes
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
  };
  
  // Handle search submission
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch({ type: 'SET_SEARCH_QUERY', payload: searchValue });
    fetchNewsData(state.selectedCategory, searchValue);
  };
  
  // Toggle search input visibility on mobile
  const toggleSearchVisibility = () => {
    setIsSearchVisible(!isSearchVisible);
  };
  
  // Clear search
  const clearSearch = () => {
    setSearchValue('');
    dispatch({ type: 'SET_SEARCH_QUERY', payload: '' });
    fetchNewsData(state.selectedCategory, '');
    setIsSearchVisible(false);
  };
  
  // Toggle dark mode
  const toggleDarkMode = () => {
    dispatch({ type: 'TOGGLE_DARK_MODE' });
  };
  
  // Focus search input when it becomes visible
  useEffect(() => {
    if (isSearchVisible && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isSearchVisible]);
  
  return (
    <header className="sticky top-0 z-10 bg-white dark:bg-gray-900 shadow-sm transition-colors duration-200">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div 
          className="text-2xl font-bold text-blue-600 dark:text-blue-400 cursor-pointer flex items-center"
          onClick={() => {
            dispatch({ type: 'SET_CATEGORY', payload: 'general' });
            dispatch({ type: 'SET_SEARCH_QUERY', payload: '' });
            setSearchValue('');
            fetchNewsData('general', '');
          }}
        >
          NewsFlow
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Desktop Search */}
          <form 
            onSubmit={handleSearchSubmit} 
            className="hidden md:flex items-center bg-gray-100 dark:bg-gray-800 rounded-full px-4 py-2"
          >
            <input
              type="text"
              placeholder="Search news..."
              value={searchValue}
              onChange={handleSearchChange}
              className="bg-transparent outline-none w-64 text-gray-700 dark:text-gray-300"
            />
            {searchValue && (
              <button
                type="button"
                onClick={clearSearch}
                className="mr-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <X size={18} />
              </button>
            )}
            <button
              type="submit"
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            >
              <Search size={18} />
            </button>
          </form>
          
          {/* Mobile Search Icon */}
          <button
            onClick={toggleSearchVisibility}
            className="md:hidden text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
          >
            <Search size={22} />
          </button>
          
          {/* Dark Mode Toggle */}
          <button
            onClick={toggleDarkMode}
            className="text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
          >
            {state.darkMode ? <Sun size={22} /> : <Moon size={22} />}
          </button>
        </div>
      </div>
      
      {/* Mobile Search Bar */}
      {isSearchVisible && (
        <div className="md:hidden container mx-auto px-4 pb-4">
          <form 
            onSubmit={handleSearchSubmit} 
            className="flex items-center bg-gray-100 dark:bg-gray-800 rounded-full px-4 py-2"
          >
            <input
              ref={searchInputRef}
              type="text"
              placeholder="Search news..."
              value={searchValue}
              onChange={handleSearchChange}
              className="bg-transparent outline-none flex-1 text-gray-700 dark:text-gray-300"
            />
            {searchValue && (
              <button
                type="button"
                onClick={clearSearch}
                className="mr-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <X size={18} />
              </button>
            )}
            <button
              type="submit"
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            >
              <Search size={18} />
            </button>
          </form>
        </div>
      )}
    </header>
  );
};

export default Header;