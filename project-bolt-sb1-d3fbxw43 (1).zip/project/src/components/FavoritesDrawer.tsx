import React from 'react';
import { X, Trash2 } from 'lucide-react';
import { useNews } from '../context/NewsContext';

interface FavoritesDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

const FavoritesDrawer: React.FC<FavoritesDrawerProps> = ({ isOpen, onClose }) => {
  const { state, dispatch } = useNews();
  const { favorites } = state;
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
    }).format(date);
  };
  
  const handleRemoveFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    dispatch({ type: 'REMOVE_FROM_FAVORITES', payload: id });
  };
  
  const handleArticleClick = (article: any) => {
    dispatch({ type: 'SET_SELECTED_ARTICLE', payload: article });
    onClose();
  };
  
  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/30 dark:bg-black/50 z-30"
          onClick={onClose}
        ></div>
      )}
      
      {/* Drawer */}
      <div 
        className={`fixed top-0 right-0 h-full w-full sm:w-96 bg-white dark:bg-gray-900 shadow-lg z-40 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="p-4 border-b border-gray-200 dark:border-gray-800 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Favorite Articles</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300"
          >
            <X size={20} />
          </button>
        </div>
        
        <div className="overflow-y-auto h-[calc(100%-64px)]">
          {favorites.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center p-8">
              <div className="bg-blue-50 dark:bg-blue-900/20 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Heart className="text-blue-500 dark:text-blue-400" size={24} />
              </div>
              <p className="text-gray-700 dark:text-gray-300 mb-2">No favorites yet</p>
              <p className="text-gray-500 dark:text-gray-400 text-sm">
                Articles you favorite will appear here for easy access.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200 dark:divide-gray-800">
              {favorites.map(article => (
                <div 
                  key={article.id}
                  onClick={() => handleArticleClick(article)}
                  className="p-4 hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer transition-colors duration-200"
                >
                  <div className="flex">
                    {article.urlToImage ? (
                      <img 
                        src={article.urlToImage} 
                        alt={article.title}
                        className="w-20 h-20 object-cover rounded"
                      />
                    ) : (
                      <div className="w-20 h-20 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center">
                        <p className="text-xs text-gray-500 dark:text-gray-400">No image</p>
                      </div>
                    )}
                    
                    <div className="ml-3 flex-1">
                      <h3 className="text-sm font-medium text-gray-900 dark:text-white line-clamp-2">{article.title}</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {article.source.name} • {formatDate(article.publishedAt)}
                      </p>
                      <div className="flex justify-end mt-2">
                        <button
                          onClick={(e) => handleRemoveFavorite(article.id, e)}
                          className="p-1.5 text-gray-500 hover:text-red-500 dark:text-gray-400 dark:hover:text-red-400 rounded-full hover:bg-red-50 dark:hover:bg-red-900/20"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

import { Heart } from 'lucide-react';

export default FavoritesDrawer;