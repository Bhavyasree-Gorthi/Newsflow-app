import React, { useState, useEffect } from 'react';
import { Heart } from 'lucide-react';
import Header from './Header';
import CategoryFilter from './CategoryFilter';
import NewsList from './NewsList';
import ArticleDetail from './ArticleDetail';
import FavoritesDrawer from './FavoritesDrawer';
import { useNews } from '../context/NewsContext';

const MainLayout: React.FC = () => {
  const { state, fetchNewsData } = useNews();
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);
  
  // Fetch initial news data
  useEffect(() => {
    fetchNewsData();
  }, []);
  
  // Toggle favorites drawer
  const toggleFavorites = () => {
    setIsFavoritesOpen(!isFavoritesOpen);
  };
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-gray-100 transition-colors duration-200">
      <Header />
      <CategoryFilter />
      
      <main className="pb-20">
        <NewsList />
      </main>
      
      {/* Floating favorites button */}
      <button
        onClick={toggleFavorites}
        className="fixed bottom-6 right-6 bg-white dark:bg-gray-800 text-blue-600 dark:text-blue-400 p-3 rounded-full shadow-lg hover:bg-blue-50 dark:hover:bg-gray-700 transition-colors duration-200 z-10 flex items-center justify-center"
      >
        <Heart size={24} fill={state.favorites.length > 0 ? 'currentColor' : 'none'} />
        {state.favorites.length > 0 && (
          <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
            {state.favorites.length}
          </span>
        )}
      </button>
      
      {/* Favorites drawer */}
      <FavoritesDrawer isOpen={isFavoritesOpen} onClose={() => setIsFavoritesOpen(false)} />
      
      {/* Article detail modal */}
      {state.selectedArticle && <ArticleDetail />}
    </div>
  );
};

export default MainLayout;