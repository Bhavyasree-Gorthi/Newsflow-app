import React from 'react';
import { useNews } from '../context/NewsContext';
import { NewsCategory } from '../types/news';

const categories: { value: NewsCategory; label: string }[] = [
  { value: 'general', label: 'General' },
  { value: 'business', label: 'Business' },
  { value: 'technology', label: 'Technology' },
  { value: 'entertainment', label: 'Entertainment' },
  { value: 'health', label: 'Health' },
  { value: 'science', label: 'Science' },
  { value: 'sports', label: 'Sports' }
];

const CategoryFilter: React.FC = () => {
  const { state, dispatch, fetchNewsData } = useNews();
  
  const handleCategoryChange = (category: NewsCategory) => {
    dispatch({ type: 'SET_CATEGORY', payload: category });
    fetchNewsData(category, state.searchQuery);
  };
  
  return (
    <div className="bg-white dark:bg-gray-900 shadow-sm transition-colors duration-200 sticky top-[72px] z-[5] py-3">
      <div className="container mx-auto px-4">
        <div className="flex space-x-1 overflow-x-auto pb-1 scrollbar-hide">
          {categories.map((category) => (
            <button
              key={category.value}
              onClick={() => handleCategoryChange(category.value)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors duration-200 ${
                state.selectedCategory === category.value
                  ? 'bg-blue-600 text-white dark:bg-blue-700'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CategoryFilter;