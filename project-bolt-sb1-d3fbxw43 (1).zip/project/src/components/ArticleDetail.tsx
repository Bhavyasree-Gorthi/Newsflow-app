import React from 'react';
import { ArrowLeft, Heart, ExternalLink } from 'lucide-react';
import { useNews } from '../context/NewsContext';

const ArticleDetail: React.FC = () => {
  const { state, dispatch } = useNews();
  const { selectedArticle, favorites } = state;
  
  if (!selectedArticle) return null;
  
  const isInFavorites = favorites.some(fav => fav.id === selectedArticle.id);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(date);
  };
  
  const handleClose = () => {
    dispatch({ type: 'SET_SELECTED_ARTICLE', payload: null });
  };
  
  const handleFavoriteToggle = () => {
    if (isInFavorites) {
      dispatch({ type: 'REMOVE_FROM_FAVORITES', payload: selectedArticle.id });
    } else {
      dispatch({ type: 'ADD_TO_FAVORITES', payload: selectedArticle });
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 dark:bg-black/80 flex items-center justify-center z-20 p-4 overflow-auto animate-fadeIn">
      <div className="bg-white dark:bg-gray-900 rounded-xl max-w-3xl w-full max-h-[90vh] flex flex-col animate-scaleIn">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center sticky top-0 bg-white dark:bg-gray-900 z-10">
          <button
            onClick={handleClose}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300"
          >
            <ArrowLeft size={20} />
          </button>
          
          <div className="flex space-x-2">
            <a 
              href={selectedArticle.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center space-x-1 px-3 py-1.5 text-sm rounded-full bg-blue-600 text-white hover:bg-blue-700 transition-colors duration-200"
            >
              <span>Visit Source</span>
              <ExternalLink size={14} />
            </a>
            
            <button
              onClick={handleFavoriteToggle}
              className={`flex items-center space-x-1 px-3 py-1.5 text-sm rounded-full transition-colors duration-200 ${
                isInFavorites 
                  ? 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-300' 
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
              }`}
            >
              <Heart size={16} fill={isInFavorites ? 'currentColor' : 'none'} />
              <span>{isInFavorites ? 'Favorited' : 'Favorite'}</span>
            </button>
          </div>
        </div>
        
        <div className="overflow-y-auto">
          {selectedArticle.urlToImage && (
            <div className="h-[30vh] relative overflow-hidden">
              <img 
                src={selectedArticle.urlToImage} 
                alt={selectedArticle.title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent h-16"></div>
            </div>
          )}
          
          <div className="p-6">
            <span className="inline-block px-3 py-1 text-sm font-medium bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 rounded-full mb-4">
              {selectedArticle.category.charAt(0).toUpperCase() + selectedArticle.category.slice(1)}
            </span>
            
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-3">
              {selectedArticle.title}
            </h1>
            
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-400 mb-6">
              <span className="mr-4">{formatDate(selectedArticle.publishedAt)}</span>
              {selectedArticle.author && (
                <>
                  <span className="mx-2">•</span>
                  <span>By {selectedArticle.author}</span>
                </>
              )}
              <span className="mx-2">•</span>
              <span>{selectedArticle.source.name}</span>
            </div>
            
            <p className="text-lg font-medium text-gray-700 dark:text-gray-200 mb-4">
              {selectedArticle.description}
            </p>
            
            <div className="prose dark:prose-invert max-w-none prose-lg prose-blue">
              {selectedArticle.content.split('\n\n').map((paragraph, index) => (
                <p key={index} className="text-gray-700 dark:text-gray-300">
                  {paragraph}
                </p>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ArticleDetail;