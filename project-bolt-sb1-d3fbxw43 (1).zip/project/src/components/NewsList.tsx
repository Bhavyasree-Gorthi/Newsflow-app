import React from 'react';
import { useNews } from '../context/NewsContext';
import NewsCard from './NewsCard';
import NewsCardSkeleton from './NewsCardSkeleton';

const NewsList: React.FC = () => {
  const { state } = useNews();
  const { articles, loading, error } = state;
  
  // Generate an array to render skeleton cards during loading
  const skeletonCards = Array(8).fill(null).map((_, index) => (
    <NewsCardSkeleton key={`skeleton-${index}`} />
  ));
  
  // Render appropriate content based on state
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {skeletonCards}
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-300 p-4 rounded-lg max-w-lg mx-auto">
          <p className="font-medium">{error}</p>
          <p className="mt-2 text-sm text-red-500 dark:text-red-400">
            Please check your connection and try again.
          </p>
        </div>
      </div>
    );
  }
  
  if (articles.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-300 p-4 rounded-lg max-w-lg mx-auto">
          <p className="font-medium">No articles found</p>
          <p className="mt-2 text-sm text-blue-500 dark:text-blue-400">
            Try adjusting your search or filter criteria.
          </p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {articles.map(article => (
          <NewsCard key={article.id} article={article} />
        ))}
      </div>
    </div>
  );
};

export default NewsList;