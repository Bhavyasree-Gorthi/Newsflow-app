import React from 'react';
import { Heart } from 'lucide-react';
import { Article } from '../types/news';
import { useNews } from '../context/NewsContext';

interface NewsCardProps {
  article: Article;
}

const NewsCard: React.FC<NewsCardProps> = ({ article }) => {
  const { state, dispatch } = useNews();
  
  const isInFavorites = state.favorites.some(fav => fav.id === article.id);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(date);
  };
  
  const handleFavoriteToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isInFavorites) {
      dispatch({ type: 'REMOVE_FROM_FAVORITES', payload: article.id });
    } else {
      dispatch({ type: 'ADD_TO_FAVORITES', payload: article });
    }
  };
  
  const handleCardClick = () => {
    dispatch({ type: 'SET_SELECTED_ARTICLE', payload: article });
  };
  
  return (
    <div 
      className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg transform hover:-translate-y-1 cursor-pointer"
      onClick={handleCardClick}
    >
      <div className="relative h-48 overflow-hidden">
        {article.urlToImage ? (
          <img 
            src={article.urlToImage} 
            alt={article.title} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
            <p className="text-gray-500 dark:text-gray-400">No image available</p>
          </div>
        )}
        <div className="absolute top-2 right-2">
          <button
            onClick={handleFavoriteToggle}
            className={`p-2 rounded-full ${
              isInFavorites 
                ? 'bg-red-100 dark:bg-red-900 text-red-500 dark:text-red-300' 
                : 'bg-gray-200/70 dark:bg-gray-700/70 text-gray-600 dark:text-gray-300'
            } transition-colors duration-200 hover:bg-red-100 dark:hover:bg-red-900 hover:text-red-500 dark:hover:text-red-300`}
          >
            <Heart size={18} fill={isInFavorites ? 'currentColor' : 'none'} />
          </button>
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
          <span className="text-xs font-medium text-white bg-blue-600 dark:bg-blue-700 px-2 py-1 rounded">
            {article.category.charAt(0).toUpperCase() + article.category.slice(1)}
          </span>
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-2 line-clamp-2 text-gray-900 dark:text-white">
          {article.title}
        </h3>
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-3 line-clamp-2">
          {article.description}
        </p>
        <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400 mt-auto">
          <span>{article.source.name}</span>
          <span>{formatDate(article.publishedAt)}</span>
        </div>
      </div>
    </div>
  );
};

export default NewsCard;