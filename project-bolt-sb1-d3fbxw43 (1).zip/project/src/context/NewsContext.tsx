import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { Article, NewsCategory, NewsState } from '../types/news';
import { fetchNews } from '../services/newsService';

// Action types
type NewsAction =
  | { type: 'SET_ARTICLES'; payload: Article[] }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'SET_CATEGORY'; payload: NewsCategory }
  | { type: 'SET_SEARCH_QUERY'; payload: string }
  | { type: 'ADD_TO_FAVORITES'; payload: Article }
  | { type: 'REMOVE_FROM_FAVORITES'; payload: string }
  | { type: 'SET_SELECTED_ARTICLE'; payload: Article | null }
  | { type: 'TOGGLE_DARK_MODE' };

// Initial state
const initialState: NewsState = {
  articles: [],
  loading: false,
  error: null,
  selectedCategory: 'general',
  searchQuery: '',
  favorites: [],
  selectedArticle: null,
  darkMode: false
};

// Create context
const NewsContext = createContext<{
  state: NewsState;
  dispatch: React.Dispatch<NewsAction>;
  fetchNewsData: (category?: NewsCategory, searchQuery?: string) => Promise<void>;
}>({
  state: initialState,
  dispatch: () => null,
  fetchNewsData: async () => {}
});

// Reducer function
const newsReducer = (state: NewsState, action: NewsAction): NewsState => {
  switch (action.type) {
    case 'SET_ARTICLES':
      return { ...state, articles: action.payload };
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    case 'SET_CATEGORY':
      return { ...state, selectedCategory: action.payload };
    case 'SET_SEARCH_QUERY':
      return { ...state, searchQuery: action.payload };
    case 'ADD_TO_FAVORITES':
      return { 
        ...state, 
        favorites: [...state.favorites, action.payload] 
      };
    case 'REMOVE_FROM_FAVORITES':
      return { 
        ...state, 
        favorites: state.favorites.filter(article => article.id !== action.payload)
      };
    case 'SET_SELECTED_ARTICLE':
      return { ...state, selectedArticle: action.payload };
    case 'TOGGLE_DARK_MODE':
      return { ...state, darkMode: !state.darkMode };
    default:
      return state;
  }
};

// Provider component
export const NewsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load favorites from localStorage
  const loadFavoritesFromStorage = (): Article[] => {
    try {
      const storedFavorites = localStorage.getItem('newsAppFavorites');
      return storedFavorites ? JSON.parse(storedFavorites) : [];
    } catch (error) {
      console.error('Error loading favorites from localStorage:', error);
      return [];
    }
  };

  // Load dark mode preference from localStorage
  const loadDarkModeFromStorage = (): boolean => {
    try {
      const storedDarkMode = localStorage.getItem('newsAppDarkMode');
      return storedDarkMode ? JSON.parse(storedDarkMode) : false;
    } catch (error) {
      console.error('Error loading dark mode from localStorage:', error);
      return false;
    }
  };

  // Initialize state with loaded values
  const [state, dispatch] = useReducer(newsReducer, {
    ...initialState,
    favorites: loadFavoritesFromStorage(),
    darkMode: loadDarkModeFromStorage()
  });

  // Save favorites to localStorage when they change
  useEffect(() => {
    localStorage.setItem('newsAppFavorites', JSON.stringify(state.favorites));
  }, [state.favorites]);

  // Save dark mode to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('newsAppDarkMode', JSON.stringify(state.darkMode));
    
    // Apply dark mode to document
    if (state.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.darkMode]);

  // Fetch news data
  const fetchNewsData = async (
    category: NewsCategory = state.selectedCategory,
    searchQuery: string = state.searchQuery
  ) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      dispatch({ type: 'SET_ERROR', payload: null });
      
      const response = await fetchNews(category, searchQuery);
      
      dispatch({ type: 'SET_ARTICLES', payload: response.articles });
    } catch (error) {
      console.error('Error fetching news:', error);
      dispatch({ 
        type: 'SET_ERROR', 
        payload: 'Failed to fetch news. Please try again later.' 
      });
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  return (
    <NewsContext.Provider value={{ state, dispatch, fetchNewsData }}>
      {children}
    </NewsContext.Provider>
  );
};

// Custom hook for using the news context
export const useNews = () => {
  const context = useContext(NewsContext);
  if (!context) {
    throw new Error('useNews must be used within a NewsProvider');
  }
  return context;
};