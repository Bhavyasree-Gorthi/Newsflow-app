import { Article, NewsApiResponse, NewsCategory } from '../types/news';
import { v4 as uuidv4 } from 'uuid';

// Mock data to simulate API responses
const mockArticles: Article[] = [
  {
    id: '1',
    title: 'New AI breakthrough could revolutionize healthcare',
    description: 'Researchers have developed a new AI system that can predict health issues before symptoms appear.',
    content: 'Researchers at a leading university have developed a groundbreaking AI system that analyzes patient data to predict potential health issues months before symptoms appear. This technology could transform preventative healthcare by allowing earlier interventions and potentially saving millions of lives worldwide.\n\nThe system, developed over five years with a diverse dataset from multiple hospitals, has shown 94% accuracy in early detection of several conditions including heart disease and certain cancers. Medical professionals are excited about the potential implications for patient care and cost reduction in healthcare systems globally.',
    author: 'Jane Smith',
    source: {
      id: 'tech-daily',
      name: 'Tech Daily'
    },
    url: 'https://example.com/ai-healthcare',
    urlToImage: 'https://images.pexels.com/photos/3825586/pexels-photo-3825586.jpeg',
    publishedAt: '2025-05-15T09:45:00Z',
    category: 'technology'
  },
  {
    id: '2',
    title: 'Global climate summit reaches historic agreement',
    description: 'World leaders have agreed to ambitious new targets to reduce carbon emissions by 2030.',
    content: 'In a landmark decision at the Global Climate Summit, 195 countries have unanimously agreed to significantly reduce carbon emissions by 2030. The historic agreement, which comes after two weeks of intense negotiations, sets binding targets for all participating nations and includes financial support for developing countries.\n\nThe deal aims to limit global temperature rises to 1.5°C above pre-industrial levels and includes mechanisms for regular progress reviews. Environmental activists have cautiously welcomed the agreement while emphasizing the need for immediate action and accountability.',
    author: 'Michael Johnson',
    source: {
      id: 'global-news',
      name: 'Global News Network'
    },
    url: 'https://example.com/climate-agreement',
    urlToImage: 'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg',
    publishedAt: '2025-05-14T15:30:00Z',
    category: 'general'
  },
  {
    id: '3',
    title: 'Stock markets hit record high as economy shows strong recovery',
    description: 'Major indices surged today as new economic data points to robust growth post-pandemic.',
    content: 'Stock markets worldwide reached unprecedented heights today following the release of strong economic indicators suggesting a robust recovery. The S&P 500, Dow Jones Industrial Average, and Nasdaq all closed at record levels, with technology and financial sectors leading the gains.\n\nEconomists attribute the surge to better-than-expected employment figures, controlled inflation rates, and increased consumer spending. However, some analysts caution that the rapid growth could lead to overvaluation in certain sectors and advise investors to remain vigilant about potential corrections in the coming months.',
    author: 'Robert Chen',
    source: {
      id: 'financial-times',
      name: 'Financial Times'
    },
    url: 'https://example.com/market-surge',
    urlToImage: 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg',
    publishedAt: '2025-05-14T20:15:00Z',
    category: 'business'
  },
  {
    id: '4',
    title: 'Revolutionary new electric vehicle unveiled with 800-mile range',
    description: 'Tech startup introduces game-changing EV technology that could end range anxiety forever.',
    content: 'A California-based tech startup has unveiled a revolutionary electric vehicle featuring groundbreaking battery technology that delivers an unprecedented 800-mile range on a single charge. The prototype, revealed at an industry showcase event, also boasts a charging time of just 15 minutes for an 80% charge using standard fast-charging infrastructure.\n\nIndustry experts suggest this development could eliminate "range anxiety" – one of the primary barriers to widespread EV adoption. The company plans to license the technology to major manufacturers rather than producing vehicles themselves, potentially accelerating the global transition to electric transportation.',
    author: 'Sarah Williams',
    source: {
      id: 'auto-tech',
      name: 'Auto Tech Today'
    },
    url: 'https://example.com/ev-breakthrough',
    urlToImage: 'https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg',
    publishedAt: '2025-05-13T12:00:00Z',
    category: 'technology'
  },
  {
    id: '5',
    title: 'Breakthrough in renewable energy storage promises grid revolution',
    description: 'Scientists develop new battery technology that could make renewable energy as reliable as fossil fuels.',
    content: 'Scientists at the National Renewable Energy Laboratory have developed a revolutionary energy storage solution that could transform how renewable energy is integrated into power grids. The new technology addresses the intermittency issues that have long challenged solar and wind power by providing cost-effective, long-duration storage capacity.\n\nThe system, which uses abundant and non-toxic materials, can store energy for up to 150 hours at costs projected to be 90% lower than current lithium-ion battery systems. Energy experts suggest this breakthrough could accelerate the global transition to renewable energy by making it as reliable and dispatchable as conventional power sources.',
    author: 'Thomas Anderson',
    source: {
      id: 'science-daily',
      name: 'Science Daily'
    },
    url: 'https://example.com/energy-breakthrough',
    urlToImage: 'https://images.pexels.com/photos/2876202/pexels-photo-2876202.jpeg',
    publishedAt: '2025-05-12T14:30:00Z',
    category: 'science'
  },
  {
    id: '6',
    title: 'Major study finds regular exercise significantly reduces dementia risk',
    description: 'Research involving over 50,000 participants shows physical activity can lower dementia risk by up to 40%.',
    content: 'A landmark 15-year study published today in the Journal of Neuroscience has found that regular exercise can reduce the risk of developing dementia by up to 40%. The research, which followed more than 50,000 adults across multiple countries, is the largest and longest study of its kind examining the relationship between physical activity and cognitive health.\n\nThe study identified that even moderate exercise – such as brisk walking for 30 minutes five times weekly – provided significant protective benefits. Researchers believe the positive effects are related to improved cardiovascular health, reduced inflammation, and the production of growth factors that support brain cell health and connections.',
    author: 'Dr. Eliza Chen',
    source: {
      id: 'health-journal',
      name: 'Health & Medicine Journal'
    },
    url: 'https://example.com/exercise-dementia',
    urlToImage: 'https://images.pexels.com/photos/40751/running-runner-long-distance-fitness-40751.jpeg',
    publishedAt: '2025-05-12T09:15:00Z',
    category: 'health'
  },
  {
    id: '7',
    title: 'Box office records shattered by surprise indie film sensation',
    description: 'Low-budget independent film becomes cultural phenomenon and highest-grossing indie release ever.',
    content: 'In an unprecedented turn of events, a low-budget independent film has become a global box office sensation, shattering records for indie releases and outperforming major studio blockbusters. Made with just $3 million, the film has already grossed over $500 million worldwide and continues to generate strong audience interest through word-of-mouth and social media buzz.\n\nIndustry analysts are calling the success a watershed moment that could transform how studios approach film financing and marketing. The director, previously unknown, shot the film using primarily unknown actors and innovative production techniques. Major studios are now reportedly in a bidding war for the filmmaker\'s next project.',
    author: 'Jessica Martinez',
    source: {
      id: 'entertainment-weekly',
      name: 'Entertainment Weekly'
    },
    url: 'https://example.com/indie-film-success',
    urlToImage: 'https://images.pexels.com/photos/33129/popcorn-movie-party-entertainment.jpg',
    publishedAt: '2025-05-11T18:45:00Z',
    category: 'entertainment'
  },
  {
    id: '8',
    title: 'Underdog team completes miraculous championship run',
    description: 'Team ranked lowest in the league at season start defeats defending champions in stunning finale.',
    content: 'In what sports commentators are calling one of the greatest underdog stories in sports history, the Metro City Mavericks have won the national championship after beginning the season ranked last in the league. Their improbable playoff run culminated in a thrilling victory over the defending champions in a game that came down to the final seconds.\n\nThe Mavericks, who had never before reached the playoffs in their 15-year history, were led by rookie coach Sarah Johnson, whose innovative strategies and team-building approach have now become the talk of the sports world. The victory parade is scheduled for this Saturday and city officials expect record attendance.',
    author: 'James Wilson',
    source: {
      id: 'sports-network',
      name: 'Sports Network'
    },
    url: 'https://example.com/underdog-champions',
    urlToImage: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg',
    publishedAt: '2025-05-11T23:10:00Z',
    category: 'sports'
  },
  {
    id: '9',
    title: 'New archaeological discovery challenges understanding of ancient civilization',
    description: 'Excavation reveals advanced technology and social structures 1,000 years earlier than previously thought.',
    content: 'Archaeologists working at a remote site have uncovered evidence that dramatically alters our understanding of an ancient civilization. The findings suggest that advanced metallurgy, complex urban planning, and sophisticated writing systems existed nearly 1,000 years earlier than previously documented.\n\nThe discovery includes well-preserved artifacts showing remarkable craftsmanship and technological innovation that experts had believed impossible for that historical period. Researchers are now reevaluating the timeline of human technological advancement and the relationships between early civilizations. The site is being described as one of the most significant archaeological discoveries of the century.',
    author: 'Dr. Marcus Reynolds',
    source: {
      id: 'history-today',
      name: 'History Today'
    },
    url: 'https://example.com/archaeology-discovery',
    urlToImage: 'https://images.pexels.com/photos/2981240/pexels-photo-2981240.jpeg',
    publishedAt: '2025-05-10T11:20:00Z',
    category: 'science'
  },
  {
    id: '10',
    title: 'Global streaming service announces revolutionary new interactive content format',
    description: 'New technology allows viewers to influence storylines in real-time, creating unique viewing experiences.',
    content: 'A leading global streaming platform has announced a groundbreaking new interactive content format that will allow viewers to influence storylines in real-time, creating uniquely personalized viewing experiences. The technology, which has been in secret development for five years, uses advanced AI to adapt narratives based on viewer preferences, reactions, and choices.\n\nThe first series using this technology will launch next month with a sci-fi thriller directed by an Academy Award-winning filmmaker. Industry experts suggest this innovation could represent the biggest shift in storytelling since the introduction of sound in cinema, potentially transforming how content is created and consumed across all entertainment media.',
    author: 'Alan Parker',
    source: {
      id: 'media-watch',
      name: 'Media Watch'
    },
    url: 'https://example.com/interactive-streaming',
    urlToImage: 'https://images.pexels.com/photos/668298/pexels-photo-668298.jpeg',
    publishedAt: '2025-05-10T16:50:00Z',
    category: 'entertainment'
  }
];

// Generate more mock data by cloning and modifying existing articles
const generateMoreMockData = () => {
  const additionalArticles: Article[] = [];
  
  mockArticles.forEach(article => {
    // Create 2 variations of each article
    for (let i = 0; i < 2; i++) {
      const newId = uuidv4();
      const dateDiff = Math.floor(Math.random() * 10) + 1;
      const date = new Date(article.publishedAt);
      date.setDate(date.getDate() - dateDiff);
      
      additionalArticles.push({
        ...article,
        id: newId,
        title: `${article.title} - Update ${i + 1}`,
        publishedAt: date.toISOString(),
      });
    }
  });
  
  return [...mockArticles, ...additionalArticles];
};

const allMockArticles = generateMoreMockData();

// Sort articles by publishedAt (newest first)
allMockArticles.sort((a, b) => 
  new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
);

// Simulate fetching news data with optional category filter
export const fetchNews = async (
  category: NewsCategory = 'general', 
  searchQuery: string = ''
): Promise<NewsApiResponse> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Filter by category if not 'general'
  let filteredArticles = category === 'general' 
    ? allMockArticles 
    : allMockArticles.filter(article => article.category === category);
  
  // Apply search query filter if present
  if (searchQuery) {
    const query = searchQuery.toLowerCase();
    filteredArticles = filteredArticles.filter(article => 
      article.title.toLowerCase().includes(query) || 
      article.description.toLowerCase().includes(query) ||
      article.content.toLowerCase().includes(query)
    );
  }
  
  return {
    status: 'ok',
    totalResults: filteredArticles.length,
    articles: filteredArticles
  };
};

// Get article by ID
export const getArticleById = async (id: string): Promise<Article | null> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const article = allMockArticles.find(article => article.id === id);
  return article || null;
};