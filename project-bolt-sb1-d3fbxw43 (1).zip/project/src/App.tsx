import React from 'react';
import { NewsProvider } from './context/NewsContext';
import MainLayout from './components/MainLayout';

function App() {
  return (
    <NewsProvider>
      <MainLayout />
    </NewsProvider>
  );
}

export default App;