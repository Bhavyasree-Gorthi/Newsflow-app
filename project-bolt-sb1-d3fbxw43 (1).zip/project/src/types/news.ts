export interface Article {
  id: string;
  title: string;
  description: string;
  content: string;
  author: string;
  source: {
    id: string | null;
    name: string;
  };
  url: string;
  urlToImage: string | null;
  publishedAt: string;
  category: string;
}

export interface NewsApiResponse {
  status: string;
  totalResults: number;
  articles: Article[];
}

export type NewsCategory = 
  | 'general' 
  | 'business' 
  | 'entertainment' 
  | 'health' 
  | 'science' 
  | 'sports' 
  | 'technology';

export interface NewsState {
  articles: Article[];
  loading: boolean;
  error: string | null;
  selectedCategory: NewsCategory;
  searchQuery: string;
  favorites: Article[];
  selectedArticle: Article | null;
  darkMode: boolean;
}